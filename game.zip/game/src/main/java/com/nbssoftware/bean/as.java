package com.nbssoftware.bean;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class as extends JPanel implements ActionListener {
    private int x = 0;
    private int y = 0;
    private int xSpeed = 2;
    private int ySpeed = 2;

    public as() {
        Timer timer = new Timer(10, this); // Timer for animation, fires every 10 milliseconds
        timer.start();
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.RED);
        g.fillOval(x, y, 50, 50); // Draw the ball
    }

    public void actionPerformed(ActionEvent e) {
        // Move the ball
        x += xSpeed;
        y += ySpeed;

        // Check for collision with the edges of the window
        if (x < 0 || x > getWidth() - 50) {
            xSpeed = -xSpeed;
        }
        if (y < 0 || y > getHeight() - 50) {
            ySpeed = -ySpeed;
        }

        repaint(); // Repaint the panel to update the animation
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Bouncing Ball Animation");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);

        as panel = new as();
        frame.add(panel);

        frame.setVisible(true);
    }
}
