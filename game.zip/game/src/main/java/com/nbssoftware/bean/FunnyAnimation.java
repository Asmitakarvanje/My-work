package com.nbssoftware.bean;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FunnyAnimation extends JPanel implements ActionListener {
    private int x = 0;
    private int y = 0;
    private int xSpeed = 2;
    private int ySpeed = 2;

    public FunnyAnimation() {
        Timer timer = new Timer(10, this); // Timer for animation, fires every 10 milliseconds
        timer.start();
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.YELLOW);
        g.fillOval(x, y, 50, 50); // Draw the head

        // Draw the eyes
        g.setColor(Color.BLACK);
        g.fillOval(x + 15, y + 15, 5, 5);
        g.fillOval(x + 30, y + 15, 5, 5);

        // Draw the mouth
        g.fillArc(x + 10, y + 20, 30, 20, 180, +180);
    }

    public void actionPerformed(ActionEvent e) {
        // Move the smiley face
        x += xSpeed;
        y += ySpeed;

        // Check for collision with the edges of the window
        if (x < 0 || x > getWidth() - 50) {
            xSpeed = -xSpeed;
        }
        if (y < 0 || y > getHeight() - 50) {
            ySpeed = -ySpeed;
        }

        repaint(); // Repaint the panel to update the animation
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Funny Animation");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);

        FunnyAnimation panel = new FunnyAnimation();
        frame.add(panel);

        frame.setVisible(true);
    }
}
