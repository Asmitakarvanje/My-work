package com.nbssoftware.bean;


import javax.swing.*;
import java.awt.*;

public class gudhipadava extends JPanel {
    private int angle = 0;
    private int angleSpeed = 2;

    public gudhipadava() {
        Timer timer = new Timer(20, e -> {
            angle += angleSpeed;
            repaint();
        });
        timer.start();
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        int centerX = getWidth() / 2;
        int centerY = getHeight() / 2;
        int rodLength = 200;
        int rodWidth = 10;
        int rodOffsetX = 5;

        // Draw the rod
        g2d.setColor(Color.BLACK);
        g2d.fillRect(centerX - rodWidth / 2 - rodOffsetX, centerY, rodWidth, rodLength);

        // Calculate the position of the Gudhi Padwa
        int gudhiHeight = 100;
        int gudhiWidth = 80;
        int gudhiX = centerX - gudhiWidth / 2;
        int gudhiY = centerY - rodLength - gudhiHeight / 2;

        // Draw the Gudhi Padwa
        g2d.setColor(Color.ORANGE);
        g2d.fillRect(gudhiX, gudhiY, gudhiWidth, gudhiHeight);

        // Draw the triangle (top part)
        int[] xPoints = {centerX - 10, centerX + 10, centerX};
        int[] yPoints = {gudhiY, gudhiY, gudhiY - 40};
        g2d.setColor(Color.GREEN);
        g2d.fillPolygon(xPoints, yPoints, 3);

        // Draw the circle (top part)
        int circleRadius = 10;
        g2d.setColor(Color.RED);
        g2d.fillOval(centerX - circleRadius, gudhiY - 40 - circleRadius, circleRadius * 2, circleRadius * 2);

        // Rotate the Gudhi Padwa
        g2d.rotate(Math.toRadians(angle), centerX, centerY);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Gudhi Padwa Animation");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);

        gudhipadava panel = new gudhipadava();
        frame.add(panel);

        frame.setVisible(true);
    }
}
