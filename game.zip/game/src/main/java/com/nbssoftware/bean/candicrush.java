package com.nbssoftware.bean;

import java.util.Random;
import java.util.Scanner;

public class candicrush {

    private static final int ROWS = 5;
    private static final int COLS = 5;
    private static final int NUM_CANDIES = 5;
    private static final char[] CANDY_SYMBOLS = {'*', '#', '@', '$', '&'};
    private static char[][] board = new char[ROWS][COLS];
    private static Random random = new Random();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        initializeBoard();
        printBoard();

        while (true) {
            System.out.println("Enter row and column (e.g., 1 2): ");
            int row1 = scanner.nextInt() - 1;
            int col1 = scanner.nextInt() - 1;
            System.out.println("Enter row and column of the candy to swap with (e.g., 2 2): ");
            int row2 = scanner.nextInt() - 1;
            int col2 = scanner.nextInt() - 1;

            if (isValidMove(row1, col1, row2, col2)) {
                swapCandies(row1, col1, row2, col2);
                if (!checkForMatches()) {
                    swapCandies(row1, col1, row2, col2); // Undo swap if it doesn't create a match
                }
            } else {
                System.out.println("Invalid move. Try again.");
            }

            printBoard();
        }
    }

    private static void initializeBoard() {
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                board[i][j] = getRandomCandy();
            }
        }
    }

    private static void printBoard() {
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                System.out.print(board[i][j] + " ");
            }
            System.out.println();
        }
    }

    private static char getRandomCandy() {
        return CANDY_SYMBOLS[random.nextInt(NUM_CANDIES)];
    }

    private static boolean isValidMove(int row1, int col1, int row2, int col2) {
        return Math.abs(row1 - row2) + Math.abs(col1 - col2) == 1; // Adjacent cells
    }

    private static void swapCandies(int row1, int col1, int row2, int col2) {
        char temp = board[row1][col1];
        board[row1][col1] = board[row2][col2];
        board[row2][col2] = temp;
    }

    private static boolean checkForMatches() {
        // Check for horizontal matches
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS - 2; j++) {
                if (board[i][j] == board[i][j + 1] && board[i][j] == board[i][j + 2]) {
                    System.out.println("Match found!");
                    return true;
                }
            }
        }

        // Check for vertical matches
        for (int j = 0; j < COLS; j++) {
            for (int i = 0; i < ROWS - 2; i++) {
                if (board[i][j] == board[i + 1][j] && board[i][j] == board[i + 2][j]) {
                    System.out.println("Match found!");
                    return true;
                }
            }
        }

        return false;
    }
}
